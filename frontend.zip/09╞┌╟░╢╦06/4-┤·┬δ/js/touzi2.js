/*
function fnWrap(){

    function fnTouzi(){
        alert('请关注网站新的产品');
    }
    fnTouzi();

}

fnWrap();
*/

// 上面的写法还会重名，可以改写成下面封闭函数的形式
// 一个分号相当于是一个空的js语句
;;;;;;;;;;

// 在前面加分号是为了防止前面一段js代码在最后没有加分号
/*;(function(){

    function fnTouzi(){
        alert('请关注网站新的产品');
    }
    fnTouzi();

})();
*/

// 封闭函数去到小括号的其他写法：

/*
;!function(){

    function fnTouzi(){
        alert('请关注网站新的产品');
    }
    fnTouzi();

}();
*/

;~function(){

    function fnTouzi(){
        alert('请关注网站新的产品');
    }
    fnTouzi();

}();


