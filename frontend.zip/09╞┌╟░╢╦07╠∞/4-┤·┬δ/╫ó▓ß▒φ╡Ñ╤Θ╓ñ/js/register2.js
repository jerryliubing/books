$(function(){

    var error_name = true;

    var $name = $('#user_name');


    /*$name.click(function(){
        $(this).next().hide();
    })

    $name.blur(function(){
        fn_check_username();
    })
    */

   $name.click(function(){
      $(this).next().hide();
    }).blur(function(){
        fn_check_username();
    })



    function fn_check_username(){
        var sVal = $name.val();
        var reUser = /^\w{6,20}$/;

        // 判断输入框是否为空
        if(sVal==''){
            error_name = true;
            $name.next().html('用户名不能为空！').show();
            return;
        }

        // 通过正则来验证输入的内容是否合法
        if(reUser.test(sVal)){
            error_name = false;
            $name.next().hide();
        }
        else{
            error_name = true;
            $name.next().html('用户名是6到20位的数字、字母或者下划线').show();
        }
    }





})