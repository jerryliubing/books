// 封闭函数
// 一个分号相当于一个空的js语句
;(function(){

    function fnTouzi(){
        alert("请关注网站新的产品");
    }
    fnTouzi();

})();

// 高级写法-1
;!function(){

    function fnTouzi(){
        alert("请关注网站新的产品");
    }
    fnTouzi();

}();

// 高级写法-2
;~function(){

    function fnTouzi(){
        alert("请关注网站新的产品");
    }
    fnTouzi();

}();





