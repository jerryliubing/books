function fnTouzi(){
    alert("请输入投资金额：")
}