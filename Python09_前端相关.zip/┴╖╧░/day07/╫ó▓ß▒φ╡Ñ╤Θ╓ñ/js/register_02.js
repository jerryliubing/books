$(function(){

    var error_name = true;
    var error_pwd = true;
    var error_check_pwd = true; 
    var error_email = true;
    var error_check = false;

    var $name = $("#user_name");
    var $pwd = $("#pwd");
    var $cpwd = $("#cpwd");
    var $email = $("#email");
    var $allow = $("#allow");
    

    // $name.click(function(){
    //     $(this).next().hide();
    // })
    // $name.blur(function(){
    //     fn_check_username();
    // })

    // 用户名的验证规则
    $name.click(function(){
        $(this).next().hide();  // 将提示信息隐藏起来
    }).blur(function(){
        fn_check_username();  // 调用验证函数
    });

    // 密码的验证规则
    $pwd.click(function(){
        $(this).next().hide();
    }).blur(function(){
        fn_check_pwd();
    });

    // 确认密码的验证规则
    $cpwd.click(function(){
        $(this).next().hide();
    }).blur(function(){
        fn_check_cpwd();
    });

    // 邮箱的验证规则
    $email.click(function(){
        $(this).next().hide();
    }).blur(function(){
        fn_check_email();
    });

    // 勾选框的验证规则
    $allow.click(function(){
        if($(this).prop("checked")){
            error_check = false;
            $(this).siblings("span").hide();
        }
        else{
            error_name = true;
            $(this).siblings("span").html("请勾选商品").show();
        }
    });









    function fn_check_username(){
        // 数字、字母或下划线
        var sVal = $name.val();
        var reUser = /^\w{6,20}$/;
        // 判断输入框是否为空
        if(sVal==""){
            error_name = true;
            $name.next().html("用户名不能为空！").show();
            return;
        }

        // 通过正则来验证输入的内容是否合法
        if(reUser.test(sVal)){
            error_name = false;
            $name.next().hide();
        }
        else{
            error_name = true;
            $name.next().html("用户名是6到20位的数字、字母或下划线").show();
        }
    } 

    function fn_check_pwd(){
        // 6到20位密码
        var sVal = $pwd.val();
        var rePwd = /^[\w@!#$%&^*]{6,20}$/;

        if(sVal==""){
            error_pwd = true;
            $pwd.next().html("密码不能为空！").show();
            return;
        }

        if(rePwd.test(sVal)){
            error_pwd = false;
            $pwd.next().hide();
        }
        else{
            error_pwd = true;
            $pwd.next().html("密码是六到20位字母、数字，还包含@#￥！%……&*字符").show();
        }
    }


    function fn_check_cpwd(){
        // 确认密码
        var pwd = $("#pwd").val();
        var cpwd = $("#cpwd").val();

        if(pwd!=cpwd){
            error_check_pwd = true;
            $cpwd.next().html("两次输入的密码不一致").show();
        }
        else{
            error_check_pwd = false;
            $cpwd.next().hide();
        }
    }


    function fn_check_email(){
        // 确认邮箱
        var sVal = $email.val();
        var reEmail = /^[a-z0-9][\w\.\-]*@[a-z0-9\-]+(\.[a-z]{2,5}){1,2}$/;

        if(sVal==""){
            error_email = true;
            $email.next().html("邮箱不能为空").show();
            return;
        }

        if(reEmail.test(sVal)){
            error_email = false;
            $email.next().hide();
        }
        else{
            error_email = true;
            $email.next().html("您输入的邮箱格式不正确").show();
        }
    }


    $(".reg_form form").submit(function(){
        if(error_name == false && error_pwd == false && error_check_pwd == false && error_email == false && error_check == false){
            return true;
        }
        else{
            return false;
        }
    });

})







 