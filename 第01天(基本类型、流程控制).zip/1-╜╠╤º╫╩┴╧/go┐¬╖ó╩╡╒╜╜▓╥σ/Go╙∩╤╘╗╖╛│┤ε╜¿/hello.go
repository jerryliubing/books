package main

import "fmt" // 我们需要fmt包中的Println函数

func main() {
	fmt.Println("hello world!!!")
}
