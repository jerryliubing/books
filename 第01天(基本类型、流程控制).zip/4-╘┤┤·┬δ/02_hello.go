package main //必须有一个main包

import "fmt" //fmt.Println()

func main() {
	fmt.Println("hello mike")
}
